DROP DATABASE projeto_pi;

CREATE DATABASE projeto_pi;

use projeto_pi;

SHOW TABLES;

--- ANTES DE EXECUTAR O BACKEND PELA PRIMEIRA VEZ EXECUTAR OS COMANDOS ACIMA


--- DEPOIS DE RODAR O BACKEND PELA PRIMEIRA VEZ, EXECUTAR OS COMANDOS ABAIXO

-- Usuários (para login e vínculo 1:1 com Cliente)
USE `projeto_pi`;

-- 1. INSERTS PARA USUARIO
INSERT INTO usuario (login, senha) VALUES
('maria.silva', 'senha123'),
('joao.oliveira', 'senha456'),
('ana.santos', 'senha789'),
('carlos.lima', 'senha101'),
('fernanda.costa', 'senha112'),
('roberto.alves', 'senha131'),
('juliana.pereira', 'senha415'),
('marcos.souza', 'senha161'),
('patricia.rocha', 'senha718'),
('ricardo.martins', 'senha919'),
('amanda.ferreira', 'senha222'),
('bruno.almeida', 'senha333');

-- 2. INSERTS PARA CLIENTE
INSERT INTO cliente (nome, CPF, usuario_id_usuario) VALUES
('Maria Silva', '123.456.789-01', 1),
('João Oliveira', '234.567.890-12', 2),
('Ana Santos', '345.678.901-23', 3),
('Carlos Lima', '456.789.012-34', 4),
('Fernanda Costa', '567.890.123-45', 5),
('Roberto Alves', '678.901.234-56', 6),
('Juliana Pereira', '789.012.345-67', 7),
('Marcos Souza', '890.123.456-78', 8),
('Patrícia Rocha', '901.234.567-89', 9),
('Ricardo Martins', '012.345.678-90', 10);

-- 3. INSERTS PARA DISTRIBUIDOR
INSERT INTO distribuidor (data_Distrib, usuario_id_usuario) VALUES
('2024-01-15 08:30:00', 11),
('2024-01-16 09:15:00', 12),
('2024-02-10 10:00:00', 1),
('2024-02-12 14:20:00', 2),
('2024-02-15 11:45:00', 3),
('2024-02-18 13:10:00', 4),
('2024-02-20 15:30:00', 5),
('2024-02-22 16:45:00', 6),
('2024-02-25 12:00:00', 7),
('2024-02-28 17:20:00', 8);

-- 4. INSERTS PARA FORNECEDOR
INSERT INTO fornecedor (nome, CNPJ) VALUES
('Sementes Premium Ltda', '12.345.678/0001-90'),
('AgroSementes Brasil', '23.456.789/0001-01'),
('Flora Nacional S.A.', '34.567.890/0001-12'),
('Cultivo Natural ME', '45.678.901/0001-23'),
('Verde Vida Sementes', '56.789.012/0001-34'),
('HortiGenética', '67.890.123/0001-45'),
('BioSementes do Campo', '78.901.234/0001-56'),
('Germina Fácil Ltda', '89.012.345/0001-67'),
('Sementeira Paulista', '90.123.456/0001-78'),
('AgroFlorestal Brasil', '01.234.567/0001-89'),
('Grifinoria Plantas Mágicas', '11.222.333/0001-44'),
('Hogwarts Horticultura', '22.333.444/0001-55');

-- 5. INSERTS PARA SEMENTES (COM DATAS CORRIGIDAS)
INSERT INTO sementes (nome_Comum, nome_Cientifico, fabricante, data_validade, quantidade_estoque, Distribuidor_id_Distribuidor) VALUES
('Alface Crespa', 'Lactuca sativa', 'Sementes Premium Ltda', '2024-12-31', 1000, 1),
('Tomate Italiano', 'Solanum lycopersicum', 'AgroSementes Brasil', '2024-11-30', 800, 2),
('Cenoura Brasília', 'Daucus carota', 'Flora Nacional S.A.', '2025-01-15', 1200, 3),
('Rúcula Cultivada', 'Eruca sativa', 'Cultivo Natural ME', '2024-10-20', 600, 4),
('Couve Manteiga', 'Brassica oleracea', 'Verde Vida Sementes', '2025-02-28', 900, 5),
('Abobrinha Italiana', 'Cucurbita pepo', 'HortiGenética', '2024-09-15', 750, 6),
('Beterraba Early Wonder', 'Beta vulgaris', 'BioSementes do Campo', '2024-12-15', 1100, 7),
('Espinafre Nova Zelândia', 'Spinacia oleracea', 'Germina Fácil Ltda', '2025-03-10', 850, 8),
('Salsinha Crespa', 'Petroselinum crispum', 'Sementeira Paulista', '2024-11-10', 950, 9),
('Manjericão Doce', 'Ocimum basilicum', 'AgroFlorestal Brasil', '2025-01-30', 700, 10),
('Pedra Filosofal', 'Magicus lapis', 'Grifinoria Plantas Mágicas', '2097-06-15', 50, 1),  -- DATA CORRIGIDA
('Feijão Mágico', 'Phaseolus magicalis', 'Hogwarts Horticultura', '2025-12-25', 150, 2);

-- 6. INSERTS PARA LOTE
INSERT INTO lote (data_Aquisic, quantidade, preco_unitario, Sementes_id_Sementes, Fornecedor_id_Fornecedor) VALUES
('2024-01-10', 1000, 2.50, 1, 1),
('2024-01-12', 800, 3.20, 2, 2),
('2024-01-14', 1200, 1.80, 3, 3),
('2024-01-16', 600, 2.10, 4, 4),
('2024-01-18', 900, 1.50, 5, 5),
('2024-01-20', 750, 2.80, 6, 6),
('2024-01-22', 1100, 1.90, 7, 7),
('2024-01-24', 850, 2.30, 8, 8),
('2024-01-26', 950, 1.70, 9, 9),
('2024-01-28', 700, 3.50, 10, 10),
('2024-02-01', 50, 99.99, 11, 11),
('2024-02-05', 150, 15.50, 12, 12);

-- 7. INSERTS PARA PEDIDO
INSERT INTO pedido (status, data_pedido, Cliente_id_Cliente) VALUES
('pendente', '2024-01-20 09:00:00', 1),
('processando', '2024-01-20 10:30:00', 2),
('enviado', '2024-01-21 14:15:00', 3),
('entregue', '2024-01-22 11:20:00', 4),
('cancelado', '2024-01-23 16:45:00', 5),
('pendente', '2024-01-25 08:15:00', 6),
('processando', '2024-01-26 13:30:00', 7),
('enviado', '2024-01-27 15:45:00', 8),
('entregue', '2024-01-28 10:20:00', 9),
('pendente', '2024-01-29 14:00:00', 10);

-- 8. INSERTS PARA ITEMPEDIDO
INSERT INTO itempedido (quant_Pedida, preco_venda, Pedido_id_Pedido, Lote_id_Lote) VALUES
(50, 3.00, 1, 1),
(30, 4.00, 1, 2),
(25, 2.50, 2, 3),
(40, 2.80, 3, 4),
(35, 2.00, 4, 5),
(20, 3.50, 5, 6),
(45, 2.40, 6, 7),
(15, 2.90, 7, 8),
(60, 2.20, 8, 9),
(28, 4.20, 9, 10),
(5, 120.00, 10, 11),
(10, 20.00, 10, 12);