package pe.senac.br.backend.repository;

import pe.senac.br.backend.model.Distribuidor;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface DistribuidorRepository extends JpaRepository<Distribuidor, Long> {
    Optional<Distribuidor> findByUsuarioId(Long usuarioId);
}