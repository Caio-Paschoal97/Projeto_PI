package pe.senac.br.backend.dto;

import java.time.LocalDateTime;

public class DistribuidorDTO {
    private Long id;
    private LocalDateTime dataDistrib;
    private UsuarioDTO usuario;
    
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public LocalDateTime getDataDistrib() {
		return dataDistrib;
	}
	public void setDataDistrib(LocalDateTime dataDistrib) {
		this.dataDistrib = dataDistrib;
	}
	public UsuarioDTO getUsuario() {
		return usuario;
	}
	public void setUsuario(UsuarioDTO usuario) {
		this.usuario = usuario;
	}

    // getters e setters
}