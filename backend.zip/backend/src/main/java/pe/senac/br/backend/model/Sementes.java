package pe.senac.br.backend.model;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "sementes")
public class Sementes {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "idSementes")
    private Long id;

    @Column(name = "nomeComum", length = 100, nullable = false)
    private String nomeComum;

    @Column(name = "nomeCientifico", length = 100)
    private String nomeCientifico;

    // NOVOS CAMPOS PARA ATENDER O FRONTEND
    @Column(name = "fabricante", length = 100)
    private String fabricante;

    @Column(name = "data_validade")
    private LocalDate dataValidade;

    @Column(name = "quantidade_estoque")
    private Integer quantidadeEstoque = 0;

    // Relacionamentos existentes
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "Distribuidor_idDistribuidor", nullable = false)
    private Distribuidor distribuidor;

    @OneToMany(mappedBy = "sementes", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Lote> lotes = new ArrayList<>();

    // Construtores
    public Sementes() {}

    public Sementes(String nomeComum, String nomeCientifico, String fabricante, LocalDate dataValidade, Integer quantidadeEstoque, Distribuidor distribuidor) {
        this.nomeComum = nomeComum;
        this.nomeCientifico = nomeCientifico;
        this.fabricante = fabricante;
        this.dataValidade = dataValidade;
        this.quantidadeEstoque = quantidadeEstoque;
        this.distribuidor = distribuidor;
    }

    // Getters e Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    
    public String getNomeComum() { return nomeComum; }
    public void setNomeComum(String nomeComum) { this.nomeComum = nomeComum; }
    
    public String getNomeCientifico() { return nomeCientifico; }
    public void setNomeCientifico(String nomeCientifico) { this.nomeCientifico = nomeCientifico; }
    
    public String getFabricante() { return fabricante; }
    public void setFabricante(String fabricante) { this.fabricante = fabricante; }
    
    public LocalDate getDataValidade() { return dataValidade; }
    public void setDataValidade(LocalDate dataValidade) { this.dataValidade = dataValidade; }
    
    public Integer getQuantidadeEstoque() { return quantidadeEstoque; }
    public void setQuantidadeEstoque(Integer quantidadeEstoque) { this.quantidadeEstoque = quantidadeEstoque; }
    
    public Distribuidor getDistribuidor() { return distribuidor; }
    public void setDistribuidor(Distribuidor distribuidor) { this.distribuidor = distribuidor; }
    
    public List<Lote> getLotes() { return lotes; }
    public void setLotes(List<Lote> lotes) { this.lotes = lotes; }
}