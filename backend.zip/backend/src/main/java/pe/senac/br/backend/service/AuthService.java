package pe.senac.br.backend.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.senac.br.backend.model.Usuario;
import pe.senac.br.backend.repository.UsuarioRepository;

import java.util.Optional;

@Service
public class AuthService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    /**
     * Verifica se há um usuário com esse login e senha.
     * @return true se credenciais válidas, false caso contrário
     */
    public boolean autenticar(String login, String senha) {
        return usuarioRepository.findByLogin(login)
               .map(u -> u.getSenha().equals(senha))
               .orElse(false);
    }

    /**
     * Busca usuário pelo login
     * @return Optional contendo o usuário se encontrado
     */
    public Optional<Usuario> buscarPorLogin(String login) {
        return usuarioRepository.findByLogin(login);
    }

    /**
     * Verifica se um usuário existe pelo login
     * @return true se o usuário existe
     */
    public boolean usuarioExiste(String login) {
        return usuarioRepository.existsByLogin(login);
    }

    /**
     * Cria um novo usuário
     * @return o usuário criado
     */
    public Usuario criarUsuario(String login, String senha) {
        if (usuarioExiste(login)) {
            throw new RuntimeException("Usuário já existe");
        }
        
        Usuario usuario = new Usuario(login, senha);
        return usuarioRepository.save(usuario);
    }

    /**
     * Atualiza a senha do usuário
     */
    public boolean atualizarSenha(String login, String novaSenha) {
        Optional<Usuario> usuarioOpt = usuarioRepository.findByLogin(login);
        if (usuarioOpt.isPresent()) {
            Usuario usuario = usuarioOpt.get();
            usuario.setSenha(novaSenha);
            usuarioRepository.save(usuario);
            return true;
        }
        return false;
    }
}