package pe.senac.br.backend.controller;

import pe.senac.br.backend.dto.SementesDTO;
import pe.senac.br.backend.dto.DistribuidorDTO;
import pe.senac.br.backend.model.Sementes;
import pe.senac.br.backend.model.Distribuidor;
import pe.senac.br.backend.repository.SementesRepository;
import pe.senac.br.backend.repository.DistribuidorRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/sementes")
@CrossOrigin(origins = "http://localhost:3000")
public class SementesController {

    private final SementesRepository sementesRepository;
    private final DistribuidorRepository distribuidorRepository;

    public SementesController(SementesRepository sementesRepository, DistribuidorRepository distribuidorRepository) {
        this.sementesRepository = sementesRepository;
        this.distribuidorRepository = distribuidorRepository;
    }

    @GetMapping
    public List<SementesDTO> listar() {
        // Use o método findAll padrão
        return sementesRepository.findAll()
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    @GetMapping("/{id}")
    public ResponseEntity<SementesDTO> buscarPorId(@PathVariable Long id) {
        return sementesRepository.findById(id)
                .map(sementes -> ResponseEntity.ok(toDTO(sementes)))
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<?> criar(@RequestBody Map<String, Object> request) {
        try {
            System.out.println("📥 Criando semente: " + request);
            
            // Buscar primeiro distribuidor automaticamente
            Distribuidor distribuidor = distribuidorRepository.findAll().stream()
                    .findFirst()
                    .orElseThrow(() -> new RuntimeException("Nenhum distribuidor cadastrado"));

            Sementes semente = new Sementes();
            semente.setNomeComum((String) request.get("nomePopular"));
            semente.setNomeCientifico((String) request.get("nomeCientifico"));
            semente.setFabricante((String) request.get("fabricante"));
            semente.setDistribuidor(distribuidor);
            
            // Data
            Object dataValidade = request.get("dataValidade");
            if (dataValidade != null && !((String) dataValidade).isEmpty()) {
                try {
                    semente.setDataValidade(LocalDate.parse((String) dataValidade));
                } catch (Exception e) {
                    semente.setDataValidade(LocalDate.now().plusYears(1));
                }
            } else {
                semente.setDataValidade(LocalDate.now().plusYears(1));
            }
            
            // Quantidade
            Object quantidade = request.get("quantidadeEstoque");
            if (quantidade != null) {
                if (quantidade instanceof Integer) {
                    semente.setQuantidadeEstoque((Integer) quantidade);
                } else if (quantidade instanceof Number) {
                    semente.setQuantidadeEstoque(((Number) quantidade).intValue());
                } else {
                    semente.setQuantidadeEstoque(0);
                }
            } else {
                semente.setQuantidadeEstoque(0);
            }
            
            Sementes salva = sementesRepository.save(semente);
            
            Map<String, Object> resposta = new HashMap<>();
            resposta.put("sucesso", true);
            resposta.put("mensagem", "Semente cadastrada com sucesso!");
            resposta.put("id", salva.getId());
            
            return ResponseEntity.ok(resposta);
            
        } catch (Exception e) {
            System.out.println("❌ Erro ao criar: " + e.getMessage());
            
            Map<String, Object> resposta = new HashMap<>();
            resposta.put("sucesso", false);
            resposta.put("mensagem", "Erro: " + e.getMessage());
            return ResponseEntity.badRequest().body(resposta);
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> atualizar(@PathVariable Long id, @RequestBody Map<String, Object> request) {
        try {
            System.out.println("📝 Atualizando semente " + id + ": " + request);
            
            return sementesRepository.findById(id)
                    .map(existente -> {
                        // Atualizar campos
                        if (request.containsKey("nomePopular")) {
                            existente.setNomeComum((String) request.get("nomePopular"));
                        }
                        if (request.containsKey("nomeCientifico")) {
                            existente.setNomeCientifico((String) request.get("nomeCientifico"));
                        }
                        if (request.containsKey("fabricante")) {
                            existente.setFabricante((String) request.get("fabricante"));
                        }
                        
                        // Data
                        if (request.containsKey("dataValidade")) {
                            Object dataValidade = request.get("dataValidade");
                            if (dataValidade != null && !((String) dataValidade).isEmpty()) {
                                try {
                                    existente.setDataValidade(LocalDate.parse((String) dataValidade));
                                } catch (Exception e) {
                                    System.out.println("⚠️ Erro na data: " + dataValidade);
                                }
                            }
                        }
                        
                        // Quantidade
                        if (request.containsKey("quantidadeEstoque")) {
                            Object quantidade = request.get("quantidadeEstoque");
                            if (quantidade != null) {
                                if (quantidade instanceof Integer) {
                                    existente.setQuantidadeEstoque((Integer) quantidade);
                                } else if (quantidade instanceof Number) {
                                    existente.setQuantidadeEstoque(((Number) quantidade).intValue());
                                }
                            }
                        }
                        
                        Sementes atualizado = sementesRepository.save(existente);
                        
                        Map<String, Object> resposta = new HashMap<>();
                        resposta.put("sucesso", true);
                        resposta.put("mensagem", "Semente atualizada com sucesso!");
                        resposta.put("semente", toSimpleDTO(atualizado));
                        
                        return ResponseEntity.ok(resposta);
                    })
                    .orElse(ResponseEntity.notFound().build());
                    
        } catch (Exception e) {
            System.out.println("❌ Erro na atualização: " + e.getMessage());
            
            Map<String, Object> resposta = new HashMap<>();
            resposta.put("sucesso", false);
            resposta.put("mensagem", "Erro: " + e.getMessage());
            return ResponseEntity.badRequest().body(resposta);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletar(@PathVariable Long id) {
        if (!sementesRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        sementesRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }

    // Métodos de conversão SIMPLES
    private SementesDTO toDTO(Sementes sementes) {
        SementesDTO dto = new SementesDTO();
        dto.setId(sementes.getId());
        dto.setNomeComum(sementes.getNomeComum());
        dto.setNomeCientifico(sementes.getNomeCientifico());
        dto.setFabricante(sementes.getFabricante());
        dto.setDataValidade(sementes.getDataValidade());
        dto.setQuantidadeEstoque(sementes.getQuantidadeEstoque());

        // Distribuidor opcional - só inclui se necessário
        if (sementes.getDistribuidor() != null) {
            DistribuidorDTO dist = new DistribuidorDTO();
            dist.setId(sementes.getDistribuidor().getId());
            dist.setDataDistrib(sementes.getDistribuidor().getDataDistrib());
            dto.setDistribuidor(dist);
        }

        return dto;
    }

    // DTO simplificado para resposta
    private Map<String, Object> toSimpleDTO(Sementes sementes) {
        Map<String, Object> dto = new HashMap<>();
        dto.put("id", sementes.getId());
        dto.put("nomeComum", sementes.getNomeComum());
        dto.put("nomeCientifico", sementes.getNomeCientifico());
        dto.put("fabricante", sementes.getFabricante());
        dto.put("dataValidade", sementes.getDataValidade());
        dto.put("quantidadeEstoque", sementes.getQuantidadeEstoque());
        return dto;
    }
}