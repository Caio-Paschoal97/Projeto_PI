package pe.senac.br.backend.controller;

import pe.senac.br.backend.dto.DistribuidorDTO;
import pe.senac.br.backend.dto.UsuarioDTO;
import pe.senac.br.backend.model.Distribuidor;
import pe.senac.br.backend.model.Usuario;
import pe.senac.br.backend.repository.DistribuidorRepository;
import pe.senac.br.backend.repository.UsuarioRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/distribuidores")
@CrossOrigin(origins = "http://localhost:3000")
public class DistribuidorController {

    private final DistribuidorRepository distribuidorRepository;
    private final UsuarioRepository usuarioRepository;

    public DistribuidorController(DistribuidorRepository distribuidorRepository, UsuarioRepository usuarioRepository) {
        this.distribuidorRepository = distribuidorRepository;
        this.usuarioRepository = usuarioRepository;
    }

    @GetMapping
    public List<DistribuidorDTO> listar() {
        return distribuidorRepository.findAll()
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    @GetMapping("/{id}")
    public ResponseEntity<DistribuidorDTO> buscarPorId(@PathVariable Long id) {
        return distribuidorRepository.findById(id)
                .map(distribuidor -> ResponseEntity.ok(toDTO(distribuidor)))
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<DistribuidorDTO> criar(@RequestBody DistribuidorDTO dto) {
        if (dto.getUsuario() != null && dto.getUsuario().getId() != null) {
            Usuario usuario = usuarioRepository.findById(dto.getUsuario().getId())
                    .orElseThrow(() -> new RuntimeException("Usuário não encontrado"));
            
            if (distribuidorRepository.findByUsuarioId(dto.getUsuario().getId()).isPresent()) {
                return ResponseEntity.badRequest().build();
            }
            
            Distribuidor distribuidor = fromDTO(dto);
            distribuidor.setUsuario(usuario);
            Distribuidor salvo = distribuidorRepository.save(distribuidor);
            return ResponseEntity.ok(toDTO(salvo));
        }
        return ResponseEntity.badRequest().build();
    }

    @PutMapping("/{id}")
    public ResponseEntity<DistribuidorDTO> atualizar(@PathVariable Long id, @RequestBody DistribuidorDTO dto) {
        return distribuidorRepository.findById(id)
                .map(existente -> {
                    existente.setDataDistrib(dto.getDataDistrib());
                    Distribuidor atualizado = distribuidorRepository.save(existente);
                    return ResponseEntity.ok(toDTO(atualizado));
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletar(@PathVariable Long id) {
        if (!distribuidorRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        distribuidorRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }

    private DistribuidorDTO toDTO(Distribuidor distribuidor) {
        DistribuidorDTO dto = new DistribuidorDTO();
        dto.setId(distribuidor.getId());
        dto.setDataDistrib(distribuidor.getDataDistrib());

        if (distribuidor.getUsuario() != null) {
            UsuarioDTO u = new UsuarioDTO();
            u.setId(distribuidor.getUsuario().getId());
            u.setLogin(distribuidor.getUsuario().getLogin());
            dto.setUsuario(u);
        }

        return dto;
    }

    private Distribuidor fromDTO(DistribuidorDTO dto) {
        Distribuidor distribuidor = new Distribuidor();
        distribuidor.setDataDistrib(dto.getDataDistrib() != null ? dto.getDataDistrib() : LocalDateTime.now());
        return distribuidor;
    }
}