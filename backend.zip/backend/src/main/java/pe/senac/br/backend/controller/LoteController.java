package pe.senac.br.backend.controller;

import pe.senac.br.backend.dto.LoteDTO;
import pe.senac.br.backend.dto.SementesDTO;
import pe.senac.br.backend.dto.FornecedorDTO;
import pe.senac.br.backend.model.Lote;
import pe.senac.br.backend.model.Sementes;
import pe.senac.br.backend.model.Fornecedor;
import pe.senac.br.backend.repository.LoteRepository;
import pe.senac.br.backend.repository.SementesRepository;
import pe.senac.br.backend.repository.FornecedorRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/lotes")
@CrossOrigin(origins = "http://localhost:3000")
public class LoteController {

    private final LoteRepository loteRepository;
    private final SementesRepository sementesRepository;
    private final FornecedorRepository fornecedorRepository;

    public LoteController(LoteRepository loteRepository, SementesRepository sementesRepository, FornecedorRepository fornecedorRepository) {
        this.loteRepository = loteRepository;
        this.sementesRepository = sementesRepository;
        this.fornecedorRepository = fornecedorRepository;
    }

    @GetMapping
    public List<LoteDTO> listar() {
        return loteRepository.findAll()
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    @GetMapping("/{id}")
    public ResponseEntity<LoteDTO> buscarPorId(@PathVariable Long id) {
        return loteRepository.findById(id)
                .map(lote -> ResponseEntity.ok(toDTO(lote)))
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/sementes/{sementesId}")
    public List<LoteDTO> buscarPorSementes(@PathVariable Long sementesId) {
        return loteRepository.findBySementesId(sementesId)
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    @GetMapping("/fornecedor/{fornecedorId}")
    public List<LoteDTO> buscarPorFornecedor(@PathVariable Long fornecedorId) {
        return loteRepository.findByFornecedorId(fornecedorId)
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    @PostMapping
    public ResponseEntity<LoteDTO> criar(@RequestBody LoteDTO dto) {
        Sementes sementes = sementesRepository.findById(dto.getSementes().getId())
                .orElseThrow(() -> new RuntimeException("Sementes não encontradas"));
        
        Fornecedor fornecedor = fornecedorRepository.findById(dto.getFornecedor().getId())
                .orElseThrow(() -> new RuntimeException("Fornecedor não encontrado"));
        
        Lote lote = fromDTO(dto);
        lote.setSementes(sementes);
        lote.setFornecedor(fornecedor);
        Lote salvo = loteRepository.save(lote);
        return ResponseEntity.ok(toDTO(salvo));
    }

    @PutMapping("/{id}")
    public ResponseEntity<LoteDTO> atualizar(@PathVariable Long id, @RequestBody LoteDTO dto) {
        return loteRepository.findById(id)
                .map(existente -> {
                    existente.setDataAquisic(dto.getDataAquisic());
                    existente.setQuantidade(dto.getQuantidade());
                    existente.setPrecoUnitario(dto.getPrecoUnitario());
                    
                    if (dto.getSementes() != null && dto.getSementes().getId() != null) {
                        Sementes sementes = sementesRepository.findById(dto.getSementes().getId())
                                .orElseThrow(() -> new RuntimeException("Sementes não encontradas"));
                        existente.setSementes(sementes);
                    }
                    
                    if (dto.getFornecedor() != null && dto.getFornecedor().getId() != null) {
                        Fornecedor fornecedor = fornecedorRepository.findById(dto.getFornecedor().getId())
                                .orElseThrow(() -> new RuntimeException("Fornecedor não encontrado"));
                        existente.setFornecedor(fornecedor);
                    }
                    
                    Lote atualizado = loteRepository.save(existente);
                    return ResponseEntity.ok(toDTO(atualizado));
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletar(@PathVariable Long id) {
        if (!loteRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        loteRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }

    private LoteDTO toDTO(Lote lote) {
        LoteDTO dto = new LoteDTO();
        dto.setId(lote.getId());
        dto.setDataAquisic(lote.getDataAquisic());
        dto.setQuantidade(lote.getQuantidade());
        dto.setPrecoUnitario(lote.getPrecoUnitario());

        if (lote.getSementes() != null) {
            SementesDTO sem = new SementesDTO();
            sem.setId(lote.getSementes().getId());
            sem.setNomeComum(lote.getSementes().getNomeComum());
            sem.setNomeCientifico(lote.getSementes().getNomeCientifico());
            dto.setSementes(sem);
        }

        if (lote.getFornecedor() != null) {
            FornecedorDTO forn = new FornecedorDTO();
            forn.setId(lote.getFornecedor().getId());
            forn.setNome(lote.getFornecedor().getNome());
            forn.setCnpj(lote.getFornecedor().getCnpj());
            dto.setFornecedor(forn);
        }

        return dto;
    }

    private Lote fromDTO(LoteDTO dto) {
        Lote lote = new Lote();
        lote.setDataAquisic(dto.getDataAquisic() != null ? dto.getDataAquisic() : LocalDate.now());
        lote.setQuantidade(dto.getQuantidade());
        lote.setPrecoUnitario(dto.getPrecoUnitario());
        return lote;
    }
}