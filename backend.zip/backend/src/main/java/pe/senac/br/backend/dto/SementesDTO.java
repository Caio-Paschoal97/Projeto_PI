package pe.senac.br.backend.dto;

import java.time.LocalDate;

public class SementesDTO {
    private Long id;
    private String nomeComum;
    private String nomeCientifico;
    private String fabricante;
    private LocalDate dataValidade;
    private Integer quantidadeEstoque;
    private DistribuidorDTO distribuidor;

    // CONSTRUTOR VAZIO OBRIGATÓRIO
    public SementesDTO() {}

    // Getters e Setters (todos devem existir)
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    
    public String getNomeComum() { return nomeComum; }
    public void setNomeComum(String nomeComum) { this.nomeComum = nomeComum; }
    
    public String getNomeCientifico() { return nomeCientifico; }
    public void setNomeCientifico(String nomeCientifico) { this.nomeCientifico = nomeCientifico; }
    
    public String getFabricante() { return fabricante; }
    public void setFabricante(String fabricante) { this.fabricante = fabricante; }
    
    public LocalDate getDataValidade() { return dataValidade; }
    public void setDataValidade(LocalDate dataValidade) { this.dataValidade = dataValidade; }
    
    public Integer getQuantidadeEstoque() { return quantidadeEstoque; }
    public void setQuantidadeEstoque(Integer quantidadeEstoque) { this.quantidadeEstoque = quantidadeEstoque; }
    
    public DistribuidorDTO getDistribuidor() { return distribuidor; }
    public void setDistribuidor(DistribuidorDTO distribuidor) { this.distribuidor = distribuidor; }
}