package pe.senac.br.backend.dto;

public class ItemPedidoDTO {
    private Long id;
    private Integer quantPedida;
    private Double precoVenda;
    private PedidoDTO pedido;
    private LoteDTO lote;
    
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Integer getQuantPedida() {
		return quantPedida;
	}
	public void setQuantPedida(Integer quantPedida) {
		this.quantPedida = quantPedida;
	}
	public Double getPrecoVenda() {
		return precoVenda;
	}
	public void setPrecoVenda(Double precoVenda) {
		this.precoVenda = precoVenda;
	}
	public PedidoDTO getPedido() {
		return pedido;
	}
	public void setPedido(PedidoDTO pedido) {
		this.pedido = pedido;
	}
	public LoteDTO getLote() {
		return lote;
	}
	public void setLote(LoteDTO lote) {
		this.lote = lote;
	}

    // getters e setters
}