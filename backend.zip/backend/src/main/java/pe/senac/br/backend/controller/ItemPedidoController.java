package pe.senac.br.backend.controller;

import pe.senac.br.backend.dto.ItemPedidoDTO;
import pe.senac.br.backend.dto.PedidoDTO;
import pe.senac.br.backend.dto.LoteDTO;
import pe.senac.br.backend.model.ItemPedido;
import pe.senac.br.backend.model.Pedido;
import pe.senac.br.backend.model.Lote;
import pe.senac.br.backend.repository.ItemPedidoRepository;
import pe.senac.br.backend.repository.PedidoRepository;
import pe.senac.br.backend.repository.LoteRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/itens-pedido")
@CrossOrigin(origins = "http://localhost:3000")
public class ItemPedidoController {

    private final ItemPedidoRepository itemPedidoRepository;
    private final PedidoRepository pedidoRepository;
    private final LoteRepository loteRepository;

    public ItemPedidoController(ItemPedidoRepository itemPedidoRepository, PedidoRepository pedidoRepository, LoteRepository loteRepository) {
        this.itemPedidoRepository = itemPedidoRepository;
        this.pedidoRepository = pedidoRepository;
        this.loteRepository = loteRepository;
    }

    @GetMapping
    public List<ItemPedidoDTO> listar() {
        return itemPedidoRepository.findAll()
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    @GetMapping("/{id}")
    public ResponseEntity<ItemPedidoDTO> buscarPorId(@PathVariable Long id) {
        return itemPedidoRepository.findById(id)
                .map(item -> ResponseEntity.ok(toDTO(item)))
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/pedido/{pedidoId}")
    public List<ItemPedidoDTO> buscarPorPedido(@PathVariable Long pedidoId) {
        return itemPedidoRepository.findByPedidoId(pedidoId)
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    @GetMapping("/lote/{loteId}")
    public List<ItemPedidoDTO> buscarPorLote(@PathVariable Long loteId) {
        return itemPedidoRepository.findByLoteId(loteId)
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    @PostMapping
    public ResponseEntity<ItemPedidoDTO> criar(@RequestBody ItemPedidoDTO dto) {
        Pedido pedido = pedidoRepository.findById(dto.getPedido().getId())
                .orElseThrow(() -> new RuntimeException("Pedido não encontrado"));
        
        Lote lote = loteRepository.findById(dto.getLote().getId())
                .orElseThrow(() -> new RuntimeException("Lote não encontrado"));
        
        ItemPedido itemPedido = fromDTO(dto);
        itemPedido.setPedido(pedido);
        itemPedido.setLote(lote);
        ItemPedido salvo = itemPedidoRepository.save(itemPedido);
        return ResponseEntity.ok(toDTO(salvo));
    }

    @PutMapping("/{id}")
    public ResponseEntity<ItemPedidoDTO> atualizar(@PathVariable Long id, @RequestBody ItemPedidoDTO dto) {
        return itemPedidoRepository.findById(id)
                .map(existente -> {
                    existente.setQuantPedida(dto.getQuantPedida());
                    existente.setPrecoVenda(dto.getPrecoVenda());
                    
                    if (dto.getPedido() != null && dto.getPedido().getId() != null) {
                        Pedido pedido = pedidoRepository.findById(dto.getPedido().getId())
                                .orElseThrow(() -> new RuntimeException("Pedido não encontrado"));
                        existente.setPedido(pedido);
                    }
                    
                    if (dto.getLote() != null && dto.getLote().getId() != null) {
                        Lote lote = loteRepository.findById(dto.getLote().getId())
                                .orElseThrow(() -> new RuntimeException("Lote não encontrado"));
                        existente.setLote(lote);
                    }
                    
                    ItemPedido atualizado = itemPedidoRepository.save(existente);
                    return ResponseEntity.ok(toDTO(atualizado));
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletar(@PathVariable Long id) {
        if (!itemPedidoRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        itemPedidoRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }

    private ItemPedidoDTO toDTO(ItemPedido itemPedido) {
        ItemPedidoDTO dto = new ItemPedidoDTO();
        dto.setId(itemPedido.getId());
        dto.setQuantPedida(itemPedido.getQuantPedida());
        dto.setPrecoVenda(itemPedido.getPrecoVenda());

        if (itemPedido.getPedido() != null) {
            PedidoDTO ped = new PedidoDTO();
            ped.setId(itemPedido.getPedido().getId());
            ped.setStatus(itemPedido.getPedido().getStatus());
            dto.setPedido(ped);
        }

        if (itemPedido.getLote() != null) {
            LoteDTO lot = new LoteDTO();
            lot.setId(itemPedido.getLote().getId());
            lot.setDataAquisic(itemPedido.getLote().getDataAquisic());
            lot.setQuantidade(itemPedido.getLote().getQuantidade());
            dto.setLote(lot);
        }

        return dto;
    }

    private ItemPedido fromDTO(ItemPedidoDTO dto) {
        ItemPedido itemPedido = new ItemPedido();
        itemPedido.setQuantPedida(dto.getQuantPedida());
        itemPedido.setPrecoVenda(dto.getPrecoVenda());
        return itemPedido;
    }
}