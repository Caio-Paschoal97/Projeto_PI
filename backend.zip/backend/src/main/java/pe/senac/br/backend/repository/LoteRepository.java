package pe.senac.br.backend.repository;

import pe.senac.br.backend.model.Lote;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface LoteRepository extends JpaRepository<Lote, Long> {
    List<Lote> findBySementesId(Long sementesId);
    List<Lote> findByFornecedorId(Long fornecedorId);
}